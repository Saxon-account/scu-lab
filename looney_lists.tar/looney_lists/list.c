/*
Author: Saxon Meznarich
ID: 07700035359
File name: list.c
Description: Implements a doubly linked circular list with nodes containing dynamic arrays.
Provides functions for list creation, deletion, insertion, removal, retrieval,
searching, and returning all elements.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>
#include "list.h"
#define index(f, n, m) (f + n - 1) % m

static int maxLength = 8;

struct list
{
    int count;
    struct node *head;
};

struct node
{
    void **data;
    int count;
    int length;
    int first; // index of the first item in the circular queue
    struct node *next;
    struct node *prev;
};

// Initializes a list
// O(1)
LIST *createList()
{
    LIST *lp;
    lp = malloc(sizeof(LIST));
    assert(lp != NULL);
    lp->count = 0;

    struct node *dummy = malloc(sizeof(struct node)); // dummy node

    lp->head = dummy;
    lp->head->next = lp->head;
    lp->head->prev = lp->head;

    return lp;
}

// Initializes a new node
// O(1)
struct node *createNode()
{
    struct node *np;
    np = (struct node *)malloc(sizeof(struct node));
    assert(np != NULL);

    np->data = (void **)malloc(sizeof(void *) * maxLength);
    assert(np->data != NULL);

    np->length = maxLength;
    np->count = 0;
    np->first = 0;
    np->next = NULL;
    np->prev = NULL;

    return np;
}

// Frees all nodes in the list, head, and list pointer EDIT
// O(n)
void destroyList(LIST *lp)
{
    assert(lp != NULL);
    struct node *pLoc = lp->head->next;
    struct node *pNext;

    while (pLoc != lp->head)
    {
        pNext = pLoc->next;
        free(pLoc->data);
        free(pLoc);
        pLoc = pNext;
    }
    free(lp->head);
    free(lp);
}

// Returns the number of items in the list
// O(1)
int numItems(LIST *lp)
{
    assert(lp != NULL);
    return lp->count;
}

// Adds item as the first item in the list, creates new node and doubles array sizes for new node if all nodes are full
// O(1)
void addFirst(LIST *lp, void *item)
{
    assert(lp != NULL);
    struct node *np = lp->head->next;

    if (np == lp->head)
    {
        struct node *pNew = createNode();
        assert(pNew != NULL);

        pNew->next = lp->head;
        pNew->prev = lp->head;
        lp->head->next = pNew;
        lp->head->prev = pNew;

        np = pNew;
    }

    if (np->count == np->length)
    {
        maxLength *= 2;
        struct node *pNew = createNode();
        assert(pNew != NULL);

        pNew->next = np;
        pNew->prev = lp->head;

        np->prev = pNew;
        lp->head->next = pNew;

        np = pNew;
    }

    np->first = index(np->first, np->length, np->length);

    np->data[np->first] = item;

    np->count++;
    lp->count++;
}

// Adds item as the last item in the list
// O(1)
void addLast(LIST *lp, void *item)
{
    assert(lp != NULL);
    struct node *np = lp->head->prev;

    if (np == lp->head)
    {
        struct node *pNew = createNode();
        assert(pNew != NULL);

        pNew->next = lp->head;
        pNew->prev = lp->head;
        lp->head->next = pNew;
        lp->head->prev = pNew;

        np = pNew;
    }

    if (np->count == np->length)
    {
        maxLength *= 2;
        printf("The size of the array is: %d", maxLength);
        struct node *pNew = createNode();
        assert(pNew != NULL);

        pNew->prev = np;
        pNew->next = lp->head;

        np->next = pNew;
        lp->head->prev = pNew;

        np = pNew;
    }

    np->data[index(np->first, np->count + 1, np->length)] = item;

    np->count++;
    lp->count++;
}

// Removes and returns the first item in the list
// O(1)
void *removeFirst(LIST *lp)
{
    assert(lp != NULL && lp->count > 0);
    struct node *np = lp->head->next;

    void *item = np->data[np->first];
    np->data[np->first] = NULL;

    np->first = index(np->first, 2, np->length);

    np->count--;
    lp->count--;

    if (np->count == 0 && lp->count > 0)
    {
        lp->head->next = np->next;
        np->next->prev = lp->head;
        free(np->data);
        free(np);
    }

    return item;
}

// Removes and returns the last item in the list
// O(1)
void *removeLast(LIST *lp)
{
    assert(lp != NULL && lp->count > 0);
    struct node *np = lp->head->prev;

    int lastIndex = index(np->first, np->count, np->length);

    void *item = np->data[lastIndex];
    np->data[lastIndex] = NULL;

    np->count--;
    lp->count--;

    if (np->count == 0 && lp->count > 0)
    {
        lp->head->prev = np->prev;
        np->prev->next = lp->head;
        free(np->data);
        free(np);
    }

    return item;
}

// Returns the first item in the list
// O(1)
void *getFirst(LIST *lp)
{
    assert(lp != NULL && lp->count > 0);
    struct node *np = lp->head->next;
    return np->data[np->first];
}

// Returns the last item in the list
// O(1)
void *getLast(LIST *lp)
{
    assert(lp != NULL && lp->count > 0);
    struct node *np = lp->head->prev;
    int lastIndex = index(np->first, np->count, np->length);
    return np->data[lastIndex];
}

// Returns the item at a specified list index from the list or NULL if it is not present
// O(logn)
void *getItem(LIST *lp, int index)
{
    assert(lp != NULL);
    if (index < 0 || index >= lp->count)
        return NULL;

    struct node *pLoc = lp->head->next;
    int itemsToSkip = index;
    int nodeIndex;
    int items = numItems(lp);

    if (index < (items / 2))
    {
        while (pLoc != lp->head)
        {
            if (itemsToSkip < pLoc->count)
            {
                break;
            }
            itemsToSkip -= pLoc->count;
            pLoc = pLoc->next;
        }
        nodeIndex = index(pLoc->first, itemsToSkip + 1, pLoc->length);
    }
    else
    {
        itemsToSkip = items - 1 - index;
        pLoc = lp->head->prev;
        while (pLoc != lp->head)
        {
            if (itemsToSkip < pLoc->count)
            {
                break;
            }
            itemsToSkip -= pLoc->count;
            pLoc = pLoc->prev;
        }
        nodeIndex = index(pLoc->first, (pLoc->count - itemsToSkip), pLoc->length);
    }
    if (pLoc == lp->head)
        return NULL;

    return pLoc->data[nodeIndex];
}

// Changes the value of specified item from the list or NULL if it is not present
// O(n)
void setItem(LIST *lp, int index, void *item)
{
    assert(lp != NULL);
    if (index < 0 || index >= lp->count)
        return NULL;

    struct node *pLoc = lp->head->next;
    int itemsToSkip = index;

    while (pLoc != lp->head)
    {
        if (itemsToSkip < pLoc->count)
        {
            break;
        }
        itemsToSkip -= pLoc->count;
        pLoc = pLoc->next;
    }
    if (pLoc == lp->head)
        return NULL;

    int nodeIndex = index(pLoc->first, itemsToSkip + 1, pLoc->length);
    pLoc->data[nodeIndex] = item;
}